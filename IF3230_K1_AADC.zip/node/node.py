import json, queue
import sys, random
import urllib.request
import signal, os, time
import threading, socket

from http.server import HTTPServer
from http.server import BaseHTTPRequestHandler
from socketserver import ThreadingMixIn 

#Read list of nodes from file
nodes_file = open("nodeslist.txt", "r")
nodeslist = nodes_file.read().split('\n')

#Read list of servers from file
server_file = open("serverlist.txt", "r")
serverlist = server_file.read().split('\n')

def getIP(address):
	return address.rsplit(':')[0]
	
def getPort(address):
	return address.rsplit(':')[1]
	
class Node():
    """
	Init
	"""    
	def __init__(self, self_ip, self_port):
        #Rank
        """
        Rank is divided to 3 categories: leader(0), follower(1), and candidate(2)
        """
        self.rank = 1
    
        #Vote
        self.vote = 0
    
        #Own Address
        self.ip = self_ip
        self.port = self_port
    
        #Term
        self.term = 0
        
    """
    GetState
    """
    def getState(self):
		return (self.state)
		
    """
    Send Receive Message
    """
    def send_msg(self, dest_ip, dest_port, msg):
		try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((dest_ip, dest_port))
            s.send(bytes(msg, 'UTF-8'))
            s.close()
		except:
            s.close()
        return
   
   def send_msg_t(self, dest_ip, dest_port, msg):
   
   def recv_msg(self, msg):
	   data = json.loads(msg.decode('UTF-8'))
	   dest_ip = data['ip']
	   dest_port = data['port']
	   
	   if(data['flag'] == 'dm' and self.state == 0):
	       
	   elif(data['flag'] == 'vr'):
		   data_args = json.loads(data['args'])
		   reply = {}
		   if(self.term < data_args['term']):
			   self.term = data_args['term']
			   self.rank = 1
		   elif(self.term == data_args['term'] and self.state == 0):
			   reply['voteGranted'] = 1
			   #reset timeout
		   else:
			   reply['voteGranted'] = 0
		   reply['term'] = self.term
		   reply['flag'] = 'vo'
		   self.send_msg_t(dest_ip, dest_port, json.dumps(reply))
	   
	   elif(data['flag'] == 'vo'):
		   data_args = json.loads(data['args'])
		   if (data_args['voteGranted']):
				self.reset_timeout()
				self.increment_vote()
			elif (self.term < data_val['term']):
				self.state = 0
				self.term = data_val['term']
				# Reset timeout
				self.reset_timeout()
    
    """
    Vote as Candidate, from Follower
    """
    
    def req_vote(self):
        self.reset_timeout()
		self.term += 1
		args = {}
		args['log_idx'] = self.log_idx
		args['term'] = self.term
		args['flag'] = 'vr'
		self.broadcast_message(json.dumps(args), self.nodes)
		return
		
    def recv_vote(self):
        self.vote += 1
	    if (self.vote >= nodes//2 + 1):
            self.rank = 1
            self.vote = 0
        return
	
	def announce_candidate(self):
	    self.rank = 2
	    self.req_vote()
	    self.recv_vote()
	    return
   
    """
    Vote other Leader
    """
    def giveVote():
	
#Main
if (len(sys.argv) == 3):
    self_ip = sys.argv[1]
    self_port = sys.argv[2]
else:
    print 'Usage: [IP_ADDRESS] [PORT]'
    sys.exit()

node = Node(self_ip, self_port)
